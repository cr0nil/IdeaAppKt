package com.karolapp.ideaappkt.model

data class ItemHome (val cryptocurrency: Rates,val iconsCurrency: List<IconsCurrency>)