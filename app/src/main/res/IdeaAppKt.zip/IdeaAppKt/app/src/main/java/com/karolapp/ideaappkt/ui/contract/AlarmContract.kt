package com.karolapp.ideaappkt.ui.contract

class AlarmContract {
    interface View : BaseContract.View {


    }

    interface Presenter : BaseContract.Presenter<View> {



    }

}