package com.karolapp.ideaappkt.di.Scope

import javax.inject.Qualifier


@Qualifier
annotation class ApplicationContext