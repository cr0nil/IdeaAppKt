package com.karolapp.ideaappkt.di.Scope

import javax.inject.Scope

@Scope
annotation class PerFragment