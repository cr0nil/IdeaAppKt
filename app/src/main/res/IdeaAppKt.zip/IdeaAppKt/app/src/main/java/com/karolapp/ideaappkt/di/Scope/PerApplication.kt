package com.karolapp.ideaappkt.di.Scope
import javax.inject.Scope

@Scope
@kotlin.annotation.Retention(AnnotationRetention.BINARY)
annotation class PerApplication