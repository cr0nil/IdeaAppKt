package com.karolapp.ideaappkt.services

interface ItemListener<T> {
    fun onClick(item: T)
}