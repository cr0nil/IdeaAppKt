# IdeaAppKt
application for checking currency values, limit request  = 100 per day
![alt text](https://github.com/cr0nil/IdeaAppKt/blob/master/ezgif.com-video-to-gif.gif "Logo Title Text 1")
